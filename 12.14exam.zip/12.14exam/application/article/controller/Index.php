<?php
namespace app\article\controller;

use app\common\model\Article;
use Qiniu\Auth;
use Qiniu\Storage\UploadManager;
use think\Config;
use think\Controller;

class Index extends Controller
{
    public function index()
    {
        return view();
    }
//    上传封面
    public function upload_photo(){
        $file = request()->file('file');
        if(!empty($file)){
            // 移动到框架应用根目录/public/uploads/ 目录下
            $info = $file->validate(['size'=>1048576,'ext'=>'jpg,png,gif'])->rule('uniqid')->move(ROOT_PATH . 'public' . DS . 'uploads');
            $error = $file->getError();
            //验证文件后缀后大小
            if(!empty($error)){
                dump($error);exit;
            }
            if($info){
                // 成功上传后 获取上传信息
                // 输出 20160820/42a79759f284b767dfcb2a0197904287.jpg
               $img = $info->getSaveName();
               session('img',$img);
                // 输出 42a79759f284b767dfcb2a0197904287.jpg
                $photo = $info->getFilename();
               $ext = $info->getExtension();

                $filePath = $info->getRealPath();

            }else{
                // 上传失败获取错误信息
                $file->getError();
            }
        }else{
            $photo = '';
        }
        if($photo !== ''){

            // 上传到七牛后保存的文件名
            $key =substr(md5($file->getRealPath()) , 0, 5). date('YmdHis') . rand(0, 9999) . '.' . $ext;
            require_once APP_PATH . './../vendor/Qiniu/autoload.php';
            // 需要填写你的 Access Key 和 Secret Key
            $accessKey = Config::get('qiniu.accessKey');
            $secretKey = Config::get('qiniu.secretKey');
            // 构建鉴权对象
            $auth = new Auth($accessKey, $secretKey);
            // 要上传的空间
            $bucket = Config::get('qiniu.bucket');
            $domain = Config::get('qiniu.DOMAIN');
            $token = $auth->uploadToken($bucket);
            $filePath = $_FILES['file']['tmp_name'];       //获取上传的图片、文件
            $filename = date("YmdHis").$_FILES["file"]["name"];        //自定义保存在七牛的文件名
            $uploadMgr = new UploadManager();       // 初始化 UploadManager 对象并进行文件的上传。
            list($ret, $err)=$uploadMgr->putFile($token, $key, $filePath);
            if ($err !== null) {
                return json(['code'=>200,'msg'=>'成功','data'=>[]]);
            } else {
                return json(['code'=>500,'msg'=>'失败','data'=>[]]);
            }

        }else{
            return ['code'=>404,'msg'=>'失败'];
        }
    }
//    数据入库
    public function addArticle(){
        $param = input();
//        验证
        $result = $this->validate($param,[
           'title|文章标题'=>'require|max:50',
            'desc|文章描述'=>'require'
        ]);
        if (true !== $result){
            return $this->error($result);
        }
        $param['pic'] = session('img');
        $param['create_time'] = time();
        $data = Article::create($param,true);
        if ($data){
            $arr = $data->toArray();
            unset($arr['/article/index/addarticle_html']);
            cache('article',$arr);
            return 'ok';
        }else{
            return "<script>alert('系统繁忙');history.go(-1)</script>";
        }
    }
//    展示
    public function show(){
        $title=input('title');
        $where = [];
        if (!empty($title)){
            $where['title'] = ["like","%$title%"];
        }
//        搜索分页倒叙
        $data = Article::where($where)->order('create_time','desc')->paginate(10,false,['query'=>input()]);
        return view('show',['data'=>$data]);
    }
    public function updel1(){

    }
    public function updel2(){

    }
    public function del(){
        $id = input('aid');
        $data = Article::destroy($id);
        if ($data){
            return json(['code'=>200,'msg'=>'成功','data'=>[]]);
        }else{
            return json(['code'=>500,'msg'=>'失败','data'=>[]]);
        }

    }
}
