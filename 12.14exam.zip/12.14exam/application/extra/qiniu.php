<?php
return [
    'accessKey'=>'ZIHn05rKDd_G_iic4MX1D96UPqILBW4Yi3_tsx9J',
    'secretKey'=>'Yz0s-0XnT-oBNVhxXPFJGVJb4g6kfCwEEmWY2sI8',
    'bucket'=>'test1511',//上传空间名称
    'DOMAIN'=>'qlaa9x0ti.hn-bkt.clouddn.com'//空间绑定的域名
];
