<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:84:"C:\Users\Lenovo\Desktop\12.14exam\public/../application/article\view\index\show.html";i:1607918328;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.0/dist/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script>
</head>
<body>
<form action="">
    文章标题 <input type="text" name="title"><input type="submit" value="搜索">
</form>
<table class="table">
    <tr>
        <th><input type="checkbox" id="selectAll" name="checkall" >选中</th>
        <th>ID</th>
        <th>文章标题</th>
        <th>文章描述</th>
        <th>文章封面</th>
        <th>文章内容</th>
        <th><a href="<?php echo url('article/index/del'); ?>" id="del">删除</a></th>
    </tr>
    <?php foreach($data as $v): ?>
    <tr>
        <td><input class="ids" type="checkbox" name="checkbox"></td>
        <td class="aid"><?php echo $v['id']; ?></td>
        <td><?php echo $v['title']; ?></td>
        <td><?php echo $v['desc']; ?></td>
        <td><img src="/uploads/<?php echo $v['pic']; ?>" alt=""></td>
        <td><?php echo $v['content']; ?></td>
        <td><a href="">删除</a></td>
    </tr>
    <?php endforeach; ?>
</table>
<div class="pagination">
    <?php echo $data->render(); ?>
</div>

</body>
</html>
<script>
    // 复选框的全选和全不选
    $('input[name="checkall"]').on("click",function(){
        if($(this).is(':checked')){

            $('input[name="checkbox"]').each(function(){
                var aid=$(this).parents('tr').next(":first-child").text();
                console.log(aid)
                $(this).prop("checked",true);

                $.ajax({
                    type: "POST",
                    url: "<?php echo url('article/index/updel1'); ?>",
                    data:{id:aid}
                });
            });
        }else{
            $('input[name="checkbox"]').each(function(){
                $(this).prop("checked",false);
                $.ajax({
                    type: "POST",
                    url: "<?php echo url('article/index/updel2'); ?>",
                    dataType: "script"
                });
            });
        }
    });
    $("#del").click(function () {
        var aid=$(this).parents('tr').next(":first-child").text();
        confirm('确定删除么？')
        $.ajax({
            type: "POST",
            url: "<?php echo url('article/index/del'); ?>",
            data:{id:aid},
            success:function (e) {
                if (e.code == 200){
                   return $(this).parent().next().html().remove();
                }
            }
        });
    })

</script>