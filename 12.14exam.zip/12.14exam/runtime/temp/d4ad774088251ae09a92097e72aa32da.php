<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:83:"C:\Users\Lenovo\Desktop\12.14exam\public/../application/article\view\index\why.html";i:1607910223;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <script src="https://apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script>
</head>
<body>
<div class="upload-btn">
    <input type="file" name="pic1" id="pic" accept="image/gif,image/jpeg,image/x-png"/>
</div>
</body>
</html>
<script>
    //上传图片
    $('#pic').change(function(event) {
        var formData = new FormData();
        formData.append("file", $(this).get(0).files[0]);
        $.ajax({
            url:'<?php echo url("article/index/upload_photo"); ?>',
            type:'POST',
            data:formData,
            cache: false,
            contentType: false,    //不可缺
            processData: false,    //不可缺
            success:function(data){
                console.log(data)
            }
        });
    });
</script>