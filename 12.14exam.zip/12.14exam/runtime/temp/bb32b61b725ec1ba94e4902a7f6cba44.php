<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:85:"C:\Users\Lenovo\Desktop\12.14exam\public/../application/article\view\index\index.html";i:1607913277;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.0/dist/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <script type="text/javascript" charset="utf-8" src="/static/futext/ueditor.config.js"></script>
    <script type="text/javascript" charset="utf-8" src="/static/futext/ueditor.all.min.js"> </script>
    <!--建议手动加在语言，避免在ie下有时因为加载语言失败导致编辑器加载失败-->
    <!--这里加载的语言文件会覆盖你在配置项目里添加的语言类型，比如你在配置项目里配置的是英文，这里加载的中文，那最后就是中文-->
    <script type="text/javascript" charset="utf-8" src="/static/futext/lang/zh-cn/zh-cn.js"></script>
    <script src="https://apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script>

</head>
<body>
<form method="post" action="<?php echo url('article/index/addArticle'); ?>" enctype="multipart/form-data">
    <div class="form-group">
        <label for="exampleInputEmail1">文章标题</label>
        <input type="text" name="title" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
         </div>
    <div class="form-group">
        <label for="exampleInputPassword1">文章描述</label>
        <input type="text" name="desc" class="form-control" id="exampleInputPassword1">
    </div>
    <div class="form-group" id="a">
        <label for="exampleInputPassword1">文章封面</label>
        <div class="upload-btn">
            <input type="file" name="pic1" id="pic" accept="image/gif,image/jpeg,image/x-png"/>
        </div>
    </div>
    <textarea name="content" id="fu"  cols="30" rows="10">

    </textarea>
    <br>
    <button type="submit" class="btn btn-primary">添加文章</button>
</form>
</body>
</html>
<script>
    UE.getEditor("fu");
</script>
<script>
    //上传图片
    $('#pic').change(function(event) {
        var formData = new FormData();
        formData.append("file", $(this).get(0).files[0]);
        $.ajax({
            url:'<?php echo url("article/index/upload_photo"); ?>',
            type:'POST',
            data:formData,
            cache: false,
            contentType: false,    //不可缺
            processData: false,    //不可缺
            success:function(data){
                console.log(data)
            }
        });
    });
</script>
































